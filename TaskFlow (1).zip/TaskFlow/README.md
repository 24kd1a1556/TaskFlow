# TaskFlow

TaskFlow is a modern, premium-feeling productivity dashboard for organizing daily
tasks, tracking progress, and staying focused. It's built as a single-page React
app with a dark, gradient, glassmorphic aesthetic — no boring white cards, no
default browser buttons.

## Features

- **Dashboard overview** — total, completed, in-progress, and overdue stats with
  a glowing accent card design, plus a filterable, sortable task list.
- **Today / Upcoming / Completed views** — dedicated pages that stay in sync with
  the same underlying task data, navigated without any page reloads.
- **Full task CRUD** — create, edit, complete, and delete tasks through a
  polished modal with validation and a smooth entrance animation.
- **Delete confirmation** — deleting always asks first, then animates the task
  out before removing it.
- **Search** — instantly filters by title, description, or category.
- **Filtering** — All / Active / Completed / High / Medium / Low priority.
- **Sorting** — due date, priority, recently added, or alphabetical.
- **Categories & priorities** — Work, Personal, Study, Health, Other; Low,
  Medium, High, each with their own accent color.
- **Persistent storage** — tasks are saved to `localStorage` and survive page
  refreshes and browser restarts. Sample tasks are seeded only the very first
  time the app runs, and never come back after you delete them.
- **Responsive layout** — the sidebar collapses into a slide-in mobile drawer
  below 900px; cards, header, and modal all reflow for small screens.
- **Accessible by default** — semantic buttons/labels, `aria-label`s on
  icon-only controls, visible focus rings, and keyboard-dismissible modals
  (<kbd>Esc</kbd> to close).

## Technologies used

- [React 18](https://react.dev/)
- [Vite 5](https://vitejs.dev/) as the build tool and dev server
- [Lucide React](https://lucide.dev/) for icons
- Plain CSS (custom properties, no framework) for styling
- Browser `localStorage` for persistence — no backend required

## Project structure

```
TaskFlow/
├── src/
│   ├── components/
│   │   ├── Sidebar.jsx        # Nav, section counts, profile footer
│   │   ├── Header.jsx         # Greeting, date, search, notifications, avatar
│   │   ├── TaskCard.jsx       # Single task row
│   │   ├── TaskList.jsx       # Filter/sort toolbar + list + empty state
│   │   ├── AddTaskModal.jsx   # Shared create/edit form
│   │   ├── ConfirmDialog.jsx  # Generic confirm/cancel dialog (used for delete)
│   │   ├── StatsCard.jsx      # Reusable stat tile
│   │   └── EmptyState.jsx     # Reusable empty-state block
│   ├── pages/
│   │   ├── Dashboard.jsx      # Stats + full task list
│   │   ├── Today.jsx          # Tasks due today
│   │   ├── Upcoming.jsx       # Future tasks
│   │   └── Completed.jsx      # Finished tasks
│   ├── hooks/
│   │   └── useTasks.js        # localStorage-backed task state
│   ├── utils/
│   │   └── taskUtils.js       # Constants, sample data, filter/sort/format helpers
│   ├── App.jsx                # Top-level state, view switching, modals
│   ├── main.jsx                # React root
│   └── index.css              # Design tokens, glass surfaces, animations
├── public/
│   └── favicon.svg
├── index.html
├── package.json
├── package-lock.json
├── vite.config.js
└── README.md
```

## Installation

```bash
npm install
```

## Running locally

```bash
npm run dev
```

Vite will start a dev server (defaults to `http://localhost:5173`) and open it
in your browser.

To build a production bundle:

```bash
npm run build
```

and preview that build locally:

```bash
npm run preview
```

## How localStorage works

All tasks live in React state via the `useTasks` hook
(`src/hooks/useTasks.js`), which:

1. On first load, checks `localStorage` for a saved task list
   (`taskflow.tasks.v1`).
2. If nothing is saved **and** the app has never seeded sample data before
   (`taskflow.seeded.v1`), it creates a small set of realistic sample tasks and
   saves both keys. This means that if you delete every task, the app will
   *not* bring the samples back on your next visit.
3. Every time the task list changes (add, edit, delete, complete), the full
   list is written back to `localStorage` via a `useEffect`.

No data ever leaves your browser — there's no backend or network call
involved in persistence.

## Future improvements

- Drag-and-drop reordering and a kanban-style board view
- Recurring tasks and reminders/notifications
- Multi-user support with a real backend and auth
- Custom, user-defined categories instead of a fixed list
- Undo toast after deleting a task, in addition to the confirmation dialog
- Keyboard shortcuts for creating and completing tasks
