import React, { useMemo, useState } from "react";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import AddTaskModal from "./components/AddTaskModal";
import ConfirmDialog from "./components/ConfirmDialog";
import Dashboard from "./pages/Dashboard";
import Today from "./pages/Today";
import Upcoming from "./pages/Upcoming";
import Completed from "./pages/Completed";
import { useTasks } from "./hooks/useTasks";
import { isToday, isUpcoming, newTaskId } from "./utils/taskUtils";

const PAGE_META = {
  dashboard: { title: null, subtitle: null }, // Header falls back to greeting + date
  today: { title: "Today", subtitle: "Everything due before midnight" },
  upcoming: { title: "Upcoming", subtitle: "What's coming down the line" },
  completed: { title: "Completed", subtitle: "A record of what you've finished" },
};

export default function App() {
  const { tasks, addTask, updateTask, deleteTask, toggleComplete } = useTasks();

  const [view, setView] = useState("dashboard");
  const [search, setSearch] = useState("");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const [modalTask, setModalTask] = useState(null); // task being edited, or {} sentinel for "add"
  const [modalOpen, setModalOpen] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [leavingId, setLeavingId] = useState(null);

  const counts = useMemo(
    () => ({
      dashboard: tasks.length,
      today: tasks.filter((t) => isToday(t.dueDate)).length,
      upcoming: tasks.filter((t) => isUpcoming(t.dueDate)).length,
      completed: tasks.filter((t) => t.completed).length,
    }),
    [tasks]
  );

  const openAddModal = () => {
    setModalTask(null);
    setModalOpen(true);
  };
  const openEditModal = (task) => {
    setModalTask(task);
    setModalOpen(true);
  };
  const closeModal = () => setModalOpen(false);

  const handleSave = (task) => {
    if (modalTask) {
      updateTask(task);
    } else {
      addTask({ ...task, id: task.id || newTaskId(), createdAt: Date.now() });
    }
    setModalOpen(false);
  };

  const requestDelete = (task) => setDeleteTarget(task);
  const cancelDelete = () => setDeleteTarget(null);
  const confirmDelete = () => {
    const id = deleteTarget.id;
    setLeavingId(id);
    setDeleteTarget(null);
    setTimeout(() => {
      deleteTask(id);
      setLeavingId(null);
    }, 190);
  };

  const sharedPageProps = {
    tasks,
    search,
    onToggleComplete: toggleComplete,
    onEdit: openEditModal,
    onDeleteRequest: requestDelete,
    onAddRequest: openAddModal,
    leavingId,
  };

  const meta = PAGE_META[view];

  return (
    <div className="app-shell">
      <div className="app-bg" aria-hidden="true">
        <span className="blob-1" />
        <span className="blob-2" />
        <span className="blob-3" />
      </div>

      <Sidebar
        activeView={view}
        onNavigate={(v) => {
          setView(v);
          setMobileNavOpen(false);
        }}
        counts={counts}
        mobileOpen={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
      />

      <main style={{ flex: 1, minWidth: 0, padding: "24px 24px 60px", position: "relative", zIndex: 1 }}>
        <Header
          title={meta.title}
          subtitle={meta.subtitle}
          search={search}
          onSearchChange={setSearch}
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        {view === "dashboard" && <Dashboard {...sharedPageProps} />}
        {view === "today" && <Today {...sharedPageProps} />}
        {view === "upcoming" && <Upcoming {...sharedPageProps} />}
        {view === "completed" && <Completed {...sharedPageProps} />}
      </main>

      {modalOpen && (
        <AddTaskModal initialTask={modalTask} onClose={closeModal} onSave={handleSave} />
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete this task?"
          message={`"${deleteTarget.title}" will be removed for good. This can't be undone.`}
          confirmLabel="Delete"
          onConfirm={confirmDelete}
          onCancel={cancelDelete}
        />
      )}
    </div>
  );
}
