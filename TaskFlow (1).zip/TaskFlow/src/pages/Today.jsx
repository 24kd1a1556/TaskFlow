import React, { useMemo, useState } from "react";
import TaskList from "../components/TaskList";
import { filterAndSortTasks, isToday } from "../utils/taskUtils";

export default function Today({ tasks, search, onToggleComplete, onEdit, onDeleteRequest, onAddRequest, leavingId }) {
  const [sortBy, setSortBy] = useState("priority");
  const todaysTasks = useMemo(() => tasks.filter((t) => isToday(t.dueDate)), [tasks]);
  const visible = useMemo(
    () => filterAndSortTasks(todaysTasks, { search, filter: "all", sortBy }),
    [todaysTasks, search, sortBy]
  );

  return (
    <TaskList
      title="Due Today"
      tasks={visible}
      sortBy={sortBy}
      onSortChange={setSortBy}
      onToggleComplete={onToggleComplete}
      onEdit={onEdit}
      onDeleteRequest={onDeleteRequest}
      onAddRequest={onAddRequest}
      leavingId={leavingId}
      isSearching={!!search.trim()}
      hideFilters
      emptyTitle="Today is clear"
      emptyMessage="Nothing due today. Enjoy the quiet, or line something up."
    />
  );
}
