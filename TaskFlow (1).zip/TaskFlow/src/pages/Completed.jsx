import React, { useMemo, useState } from "react";
import TaskList from "../components/TaskList";
import { filterAndSortTasks } from "../utils/taskUtils";

export default function Completed({ tasks, search, onToggleComplete, onEdit, onDeleteRequest, leavingId }) {
  const [sortBy, setSortBy] = useState("recent");
  const completedTasks = useMemo(() => tasks.filter((t) => t.completed), [tasks]);
  const visible = useMemo(
    () => filterAndSortTasks(completedTasks, { search, filter: "all", sortBy }),
    [completedTasks, search, sortBy]
  );

  return (
    <TaskList
      title="Completed"
      tasks={visible}
      sortBy={sortBy}
      onSortChange={setSortBy}
      onToggleComplete={onToggleComplete}
      onEdit={onEdit}
      onDeleteRequest={onDeleteRequest}
      leavingId={leavingId}
      isSearching={!!search.trim()}
      hideFilters
      emptyTitle="Nothing completed yet"
      emptyMessage="Finished tasks will collect here so you can look back on your progress."
    />
  );
}
