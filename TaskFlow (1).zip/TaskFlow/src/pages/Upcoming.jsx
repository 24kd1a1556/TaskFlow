import React, { useMemo, useState } from "react";
import TaskList from "../components/TaskList";
import { filterAndSortTasks, isUpcoming } from "../utils/taskUtils";

export default function Upcoming({ tasks, search, onToggleComplete, onEdit, onDeleteRequest, onAddRequest, leavingId }) {
  const [sortBy, setSortBy] = useState("dueDate");
  const upcomingTasks = useMemo(() => tasks.filter((t) => isUpcoming(t.dueDate)), [tasks]);
  const visible = useMemo(
    () => filterAndSortTasks(upcomingTasks, { search, filter: "all", sortBy }),
    [upcomingTasks, search, sortBy]
  );

  return (
    <TaskList
      title="Upcoming"
      tasks={visible}
      sortBy={sortBy}
      onSortChange={setSortBy}
      onToggleComplete={onToggleComplete}
      onEdit={onEdit}
      onDeleteRequest={onDeleteRequest}
      onAddRequest={onAddRequest}
      leavingId={leavingId}
      isSearching={!!search.trim()}
      hideFilters
      emptyTitle="Nothing on the horizon"
      emptyMessage="No upcoming tasks scheduled yet."
    />
  );
}
