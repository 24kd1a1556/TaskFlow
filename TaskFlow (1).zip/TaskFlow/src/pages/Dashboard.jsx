import React, { useMemo, useState } from "react";
import { ListChecks, CheckCircle2, Clock3, AlertTriangle } from "lucide-react";
import StatsCard from "../components/StatsCard";
import TaskList from "../components/TaskList";
import { computeStats, filterAndSortTasks } from "../utils/taskUtils";

export default function Dashboard({ tasks, search, onToggleComplete, onEdit, onDeleteRequest, onAddRequest, leavingId }) {
  const [filter, setFilter] = useState("all");
  const [sortBy, setSortBy] = useState("dueDate");

  const stats = useMemo(() => computeStats(tasks), [tasks]);
  const visible = useMemo(
    () => filterAndSortTasks(tasks, { search, filter, sortBy }),
    [tasks, search, filter, sortBy]
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <section
        className="fade-up"
        style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 14 }}
      >
        <StatsCard label="Total Tasks" value={stats.total} icon={ListChecks} accent="#8b5cf6" />
        <StatsCard label="Completed" value={stats.completed} icon={CheckCircle2} accent="#4ade80" indicator={`${stats.percent}%`} />
        <StatsCard label="In Progress" value={stats.inProgress} icon={Clock3} accent="#22d3ee" />
        <StatsCard label="Overdue" value={stats.overdue} icon={AlertTriangle} accent="#fb7185" />
      </section>

      <TaskList
        title="Today's Tasks"
        tasks={visible}
        filter={filter}
        onFilterChange={setFilter}
        sortBy={sortBy}
        onSortChange={setSortBy}
        onToggleComplete={onToggleComplete}
        onEdit={onEdit}
        onDeleteRequest={onDeleteRequest}
        onAddRequest={onAddRequest}
        leavingId={leavingId}
        isSearching={!!search.trim()}
        emptyTitle="You're all caught up!"
        emptyMessage="No tasks waiting for you. Create one to get started."
      />
    </div>
  );
}
