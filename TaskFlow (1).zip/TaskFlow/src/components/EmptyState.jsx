import React from "react";
import { Sparkles } from "lucide-react";

export default function EmptyState({ title, message, actionLabel, onAction }) {
  return (
    <div
      className="fade-up"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
        padding: "56px 16px",
      }}
    >
      <div
        aria-hidden="true"
        className="glass"
        style={{
          width: 48,
          height: 48,
          borderRadius: 16,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 16,
        }}
      >
        <Sparkles size={20} color="var(--accent-violet)" />
      </div>
      <p className="font-display" style={{ margin: 0, fontSize: 17, fontWeight: 600 }}>
        {title}
      </p>
      <p style={{ margin: "6px 0 0", fontSize: 13, color: "var(--text-2)", maxWidth: 260 }}>{message}</p>
      {actionLabel && (
        <button onClick={onAction} className="btn-primary" style={{ marginTop: 18, padding: "10px 18px", borderRadius: 12, fontSize: 14, fontWeight: 600 }}>
          {actionLabel}
        </button>
      )}
    </div>
  );
}
