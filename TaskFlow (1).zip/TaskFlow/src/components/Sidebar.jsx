import React from "react";
import {
  Sparkles,
  LayoutDashboard,
  CalendarDays,
  CalendarRange,
  CheckCircle2,
  Tag,
  Settings,
  X,
} from "lucide-react";

const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "today", label: "Today", icon: CalendarDays },
  { id: "upcoming", label: "Upcoming", icon: CalendarRange },
  { id: "completed", label: "Completed", icon: CheckCircle2 },
];

export default function Sidebar({ activeView, onNavigate, counts, mobileOpen, onCloseMobile }) {
  return (
    <>
      {mobileOpen && (
        <div
          className="mobile-only"
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(5,2,15,0.6)",
            zIndex: 55,
          }}
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`glass desktop-sidebar ${mobileOpen ? "open" : ""}`}
        style={{
          width: 264,
          flexShrink: 0,
          display: "flex",
          flexDirection: "column",
          padding: 20,
          height: "100vh",
          position: "sticky",
          top: 0,
        }}
        aria-label="Main navigation"
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 28 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Sparkles size={20} color="var(--accent-violet)" />
            <span className="font-display gradient-text" style={{ fontWeight: 700, fontSize: 19 }}>
              TaskFlow
            </span>
          </div>
          <button
            className="mobile-only"
            onClick={onCloseMobile}
            aria-label="Close menu"
            style={{ background: "none", border: "none", color: "var(--text-2)", padding: 4 }}
          >
            <X size={18} />
          </button>
        </div>

        <nav style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeView === item.id;
            const count = counts[item.id];
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`nav-item ${active ? "active" : ""}`}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "10px 14px",
                  borderRadius: 12,
                  border: "none",
                  background: "transparent",
                  color: active ? "var(--text-1)" : "var(--text-2)",
                  fontSize: 14,
                  fontWeight: 500,
                  textAlign: "left",
                }}
              >
                <Icon size={16} />
                <span style={{ flex: 1 }}>{item.label}</span>
                {typeof count === "number" && (
                  <span
                    className="font-mono"
                    style={{
                      fontSize: 11,
                      padding: "1px 8px",
                      borderRadius: 999,
                      background: active ? "rgba(255,255,255,0.18)" : "var(--surface-strong)",
                      color: active ? "var(--text-1)" : "var(--text-3)",
                    }}
                  >
                    {count}
                  </span>
                )}
              </button>
            );
          })}

          <div style={{ height: 1, background: "var(--border)", margin: "14px 4px" }} />

          <button
            className="nav-item"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              padding: "10px 14px",
              borderRadius: 12,
              border: "none",
              background: "transparent",
              color: "var(--text-2)",
              fontSize: 14,
              fontWeight: 500,
              textAlign: "left",
            }}
          >
            <Tag size={16} />
            Categories
          </button>
          <button
            className="nav-item"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              padding: "10px 14px",
              borderRadius: 12,
              border: "none",
              background: "transparent",
              color: "var(--text-2)",
              fontSize: 14,
              fontWeight: 500,
              textAlign: "left",
            }}
          >
            <Settings size={16} />
            Settings
          </button>
        </nav>

        <div style={{ marginTop: "auto", paddingTop: 16, borderTop: "1px solid var(--border)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 6px" }}>
            <div
              aria-hidden="true"
              style={{
                width: 36,
                height: 36,
                borderRadius: "50%",
                background: "linear-gradient(135deg, var(--accent-violet), var(--accent-cyan))",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                fontWeight: 700,
                fontSize: 14,
                flexShrink: 0,
              }}
            >
              A
            </div>
            <div style={{ minWidth: 0 }}>
              <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: "var(--text-1)" }}>Alex Rivera</p>
              <p style={{ margin: 0, fontSize: 11, color: "var(--text-3)" }}>alex@taskflow.app</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
