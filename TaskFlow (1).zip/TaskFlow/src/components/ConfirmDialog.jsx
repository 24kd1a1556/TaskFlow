import React, { useEffect, useRef } from "react";

export default function ConfirmDialog({ title, message, confirmLabel = "Confirm", onConfirm, onCancel }) {
  const confirmRef = useRef(null);

  useEffect(() => {
    confirmRef.current?.focus();
    const onKey = (e) => e.key === "Escape" && onCancel();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);

  return (
    <div
      className="backdrop-in"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 80,
        background: "rgba(6,3,16,0.6)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
      }}
      onClick={onCancel}
    >
      <div
        className="glass-strong modal-in"
        role="alertdialog"
        aria-modal="true"
        aria-label={title}
        style={{ width: "100%", maxWidth: 360, borderRadius: "var(--radius-lg)", padding: 24 }}
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="font-display" style={{ margin: 0, fontSize: 17, fontWeight: 600 }}>
          {title}
        </h3>
        <p style={{ margin: "8px 0 20px", fontSize: 13.5, color: "var(--text-2)", lineHeight: 1.5 }}>{message}</p>
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={onCancel} className="btn-ghost" style={{ flex: 1, padding: "10px 0", borderRadius: 12, fontSize: 14, fontWeight: 500 }}>
            Cancel
          </button>
          <button
            ref={confirmRef}
            onClick={onConfirm}
            style={{
              flex: 1,
              padding: "10px 0",
              borderRadius: 12,
              fontSize: 14,
              fontWeight: 600,
              border: "none",
              color: "white",
              background: "linear-gradient(135deg, var(--accent-coral), #f43f5e)",
            }}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
