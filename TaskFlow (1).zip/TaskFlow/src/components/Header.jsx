import React from "react";
import { Menu, Search, Bell } from "lucide-react";
import { formatFullDate } from "../utils/taskUtils";

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

export default function Header({ title, subtitle, search, onSearchChange, onOpenMobileNav }) {
  return (
    <header
      className="fade-up"
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 16,
        flexWrap: "wrap",
        marginBottom: 28,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 0 }}>
        <button
          className="mobile-only glass"
          onClick={onOpenMobileNav}
          aria-label="Open menu"
          style={{ border: "1px solid var(--border)", borderRadius: 12, padding: 10, color: "var(--text-1)" }}
        >
          <Menu size={18} />
        </button>
        <div style={{ minWidth: 0 }}>
          <h1 className="font-display" style={{ margin: 0, fontSize: 26, fontWeight: 700, lineHeight: 1.2 }}>
            {title || `${greeting()} 👋`}
          </h1>
          <p style={{ margin: "2px 0 0", color: "var(--text-2)", fontSize: 13 }}>
            {subtitle || formatFullDate()}
          </p>
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ position: "relative" }}>
          <Search
            size={15}
            style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--text-3)" }}
          />
          <input
            type="search"
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search tasks…"
            aria-label="Search tasks"
            className="input-field"
            style={{ paddingLeft: 34, width: 200 }}
          />
        </div>

        <button
          className="glass"
          aria-label="Notifications"
          style={{ border: "1px solid var(--border)", borderRadius: 12, padding: 10, color: "var(--text-2)", position: "relative" }}
        >
          <Bell size={17} />
          <span
            aria-hidden="true"
            style={{
              position: "absolute",
              top: 7,
              right: 7,
              width: 7,
              height: 7,
              borderRadius: "50%",
              background: "var(--accent-coral)",
            }}
          />
        </button>

        <div
          aria-hidden="true"
          style={{
            width: 38,
            height: 38,
            borderRadius: "50%",
            background: "linear-gradient(135deg, var(--accent-violet), var(--accent-cyan))",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "white",
            fontWeight: 700,
            fontSize: 14,
          }}
        >
          A
        </div>
      </div>
    </header>
  );
}
