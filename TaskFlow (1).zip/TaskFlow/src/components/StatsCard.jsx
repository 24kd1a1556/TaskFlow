import React from "react";

export default function StatsCard({ label, value, icon: Icon, accent, indicator }) {
  return (
    <div
      className="glass fade-up"
      style={{
        borderRadius: "var(--radius-md)",
        padding: 18,
        position: "relative",
        overflow: "hidden",
        minHeight: 104,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      }}
    >
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          top: -20,
          right: -20,
          width: 80,
          height: 80,
          borderRadius: "50%",
          background: accent,
          opacity: 0.18,
          filter: "blur(20px)",
        }}
      />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", position: "relative" }}>
        <span style={{ fontSize: 12, letterSpacing: 0.4, color: "var(--text-2)", textTransform: "uppercase" }}>
          {label}
        </span>
        <div
          aria-hidden="true"
          style={{
            width: 30,
            height: 30,
            borderRadius: 10,
            background: `${accent}22`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Icon size={15} color={accent} />
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8, position: "relative" }}>
        <span className="font-mono" style={{ fontSize: 30, fontWeight: 600 }}>
          {value}
        </span>
        {indicator && (
          <span style={{ fontSize: 12, color: accent, fontWeight: 500 }}>{indicator}</span>
        )}
      </div>
    </div>
  );
}
