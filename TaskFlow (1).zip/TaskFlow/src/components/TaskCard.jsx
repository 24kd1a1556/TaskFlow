import React from "react";
import { CheckCircle2, Pencil, Trash2, Clock, CalendarDays } from "lucide-react";
import { PRIORITIES, categoryColor, formatDueDate, isOverdue } from "../utils/taskUtils";

export default function TaskCard({ task, onToggleComplete, onEdit, onDeleteRequest, isLeaving }) {
  const priority = PRIORITIES[task.priority] || PRIORITIES.medium;
  const catColor = categoryColor(task.category);
  const overdue = isOverdue(task);
  const dueLabel = formatDueDate(task.dueDate);

  return (
    <div
      className={`task-card glass ${isLeaving ? "leaving" : ""}`}
      style={{
        borderRadius: "var(--radius-md)",
        padding: "14px 16px",
        display: "flex",
        gap: 14,
        alignItems: "flex-start",
      }}
    >
      <button
        onClick={() => onToggleComplete(task.id)}
        aria-label={task.completed ? "Mark task as not completed" : "Mark task as completed"}
        className={task.completed ? "check-pop" : ""}
        style={{
          marginTop: 2,
          width: 24,
          height: 24,
          borderRadius: "50%",
          flexShrink: 0,
          border: task.completed ? "none" : "2px solid var(--border)",
          background: task.completed ? "linear-gradient(135deg, var(--accent-violet), var(--accent-cyan))" : "transparent",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {task.completed && <CheckCircle2 size={14} color="white" strokeWidth={3} />}
      </button>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8 }}>
          <p
            className={`font-display ${task.completed ? "task-title-done" : ""}`}
            style={{ margin: 0, fontSize: 15, fontWeight: 600 }}
          >
            {task.title}
          </p>
          <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
            <button
              onClick={() => onEdit(task)}
              aria-label="Edit task"
              style={{ background: "none", border: "none", padding: 6, borderRadius: 8, color: "var(--text-2)" }}
            >
              <Pencil size={14} />
            </button>
            <button
              onClick={() => onDeleteRequest(task)}
              aria-label="Delete task"
              style={{ background: "none", border: "none", padding: 6, borderRadius: 8, color: "var(--text-2)" }}
            >
              <Trash2 size={14} />
            </button>
          </div>
        </div>

        {task.description && (
          <p
            style={{
              margin: "3px 0 0",
              fontSize: 13,
              color: "var(--text-2)",
              opacity: task.completed ? 0.55 : 1,
              lineHeight: 1.4,
            }}
          >
            {task.description}
          </p>
        )}

        <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 10, flexWrap: "wrap" }}>
          <span
            style={{
              fontSize: 11,
              fontWeight: 500,
              padding: "2px 9px",
              borderRadius: 999,
              background: `${catColor}22`,
              color: catColor,
              border: `1px solid ${catColor}44`,
            }}
          >
            {task.category}
          </span>

          <span style={{ fontSize: 11, fontWeight: 600, color: priority.color, display: "flex", alignItems: "center", gap: 4 }}>
            <span aria-hidden="true" style={{ width: 6, height: 6, borderRadius: "50%", background: priority.color }} />
            {priority.label}
          </span>

          <span
            style={{
              fontSize: 11,
              color: overdue ? "var(--accent-coral)" : "var(--text-3)",
              display: "flex",
              alignItems: "center",
              gap: 4,
            }}
          >
            <CalendarDays size={11} />
            {dueLabel}
            {overdue && " · overdue"}
          </span>

          {task.dueTime && (
            <span style={{ fontSize: 11, color: "var(--text-3)", display: "flex", alignItems: "center", gap: 4 }}>
              <Clock size={11} />
              {task.dueTime}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
