import React, { useState } from "react";
import { Plus, ArrowUpDown, ChevronDown, ListFilter } from "lucide-react";
import TaskCard from "./TaskCard";
import EmptyState from "./EmptyState";

const FILTERS = [
  { id: "all", label: "All" },
  { id: "active", label: "Active" },
  { id: "completed", label: "Completed" },
  { id: "high", label: "High priority" },
  { id: "medium", label: "Medium priority" },
  { id: "low", label: "Low priority" },
];

const SORTS = {
  dueDate: "Due date",
  priority: "Priority",
  recent: "Recently added",
  alphabetical: "Alphabetical",
};

export default function TaskList({
  title,
  tasks,
  filter,
  onFilterChange,
  sortBy,
  onSortChange,
  onToggleComplete,
  onEdit,
  onDeleteRequest,
  onAddRequest,
  emptyTitle,
  emptyMessage,
  hideFilters,
  isSearching,
  leavingId,
}) {
  const [sortOpen, setSortOpen] = useState(false);

  return (
    <section className="glass fade-up" style={{ borderRadius: "var(--radius-lg)", padding: 18 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 14 }}>
        <h2 className="font-display" style={{ margin: 0, fontSize: 17, fontWeight: 600 }}>
          {title}
        </h2>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ position: "relative" }}>
            <button
              onClick={() => setSortOpen((o) => !o)}
              className="btn-ghost"
              style={{ display: "flex", alignItems: "center", gap: 6, borderRadius: 10, padding: "8px 12px", fontSize: 13 }}
              aria-haspopup="listbox"
              aria-expanded={sortOpen}
            >
              <ArrowUpDown size={13} />
              {SORTS[sortBy]}
              <ChevronDown size={13} />
            </button>
            {sortOpen && (
              <div
                className="glass-strong"
                role="listbox"
                style={{ position: "absolute", right: 0, marginTop: 6, width: 168, borderRadius: 12, padding: 6, zIndex: 20 }}
              >
                {Object.entries(SORTS).map(([key, label]) => (
                  <button
                    key={key}
                    role="option"
                    aria-selected={sortBy === key}
                    onClick={() => {
                      onSortChange(key);
                      setSortOpen(false);
                    }}
                    style={{
                      display: "block",
                      width: "100%",
                      textAlign: "left",
                      padding: "8px 10px",
                      borderRadius: 8,
                      border: "none",
                      background: "transparent",
                      color: sortBy === key ? "var(--accent-violet)" : "var(--text-1)",
                      fontSize: 13,
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {onAddRequest && (
            <button
              onClick={onAddRequest}
              className="btn-primary"
              style={{ display: "flex", alignItems: "center", gap: 6, borderRadius: 10, padding: "8px 14px", fontSize: 13, fontWeight: 600 }}
            >
              <Plus size={14} /> Add Task
            </button>
          )}
        </div>
      </div>

      {!hideFilters && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
          <ListFilter size={13} color="var(--text-3)" />
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => onFilterChange(f.id)}
              style={{
                padding: "6px 12px",
                borderRadius: 999,
                fontSize: 12,
                fontWeight: 500,
                border: `1px solid ${filter === f.id ? "transparent" : "var(--border)"}`,
                background: filter === f.id ? "linear-gradient(90deg, var(--accent-violet), var(--accent-cyan))" : "var(--surface)",
                color: filter === f.id ? "white" : "var(--text-2)",
              }}
            >
              {f.label}
            </button>
          ))}
        </div>
      )}

      {tasks.length === 0 ? (
        <EmptyState
          title={isSearching ? "No matches found" : emptyTitle || "Nothing here yet"}
          message={isSearching ? "Try a different search term." : emptyMessage || "Tasks will show up here."}
          actionLabel={!isSearching && onAddRequest ? "Create a task" : undefined}
          onAction={onAddRequest}
        />
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {tasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              onToggleComplete={onToggleComplete}
              onEdit={onEdit}
              onDeleteRequest={onDeleteRequest}
              isLeaving={task.id === leavingId}
            />
          ))}
        </div>
      )}
    </section>
  );
}
