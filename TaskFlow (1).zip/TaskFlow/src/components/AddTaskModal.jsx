import React, { useEffect, useRef, useState } from "react";
import { X, Flame } from "lucide-react";
import { CATEGORIES, PRIORITIES, createEmptyTask } from "../utils/taskUtils";

export default function AddTaskModal({ initialTask, onClose, onSave }) {
  const isEdit = !!initialTask;
  const [form, setForm] = useState(initialTask || createEmptyTask());
  const [error, setError] = useState("");
  const titleRef = useRef(null);

  useEffect(() => {
    titleRef.current?.focus();
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const setField = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title.trim()) {
      setError("Give the task a title.");
      return;
    }
    onSave({ ...form, title: form.title.trim(), description: form.description.trim() });
  };

  return (
    <div
      className="backdrop-in"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 80,
        background: "rgba(6,3,16,0.6)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
      }}
      onClick={onClose}
    >
      <form
        onSubmit={handleSubmit}
        className="glass-strong modal-in scroll-thin"
        role="dialog"
        aria-modal="true"
        aria-label={isEdit ? "Edit task" : "Add task"}
        style={{
          width: "100%",
          maxWidth: 440,
          maxHeight: "90vh",
          overflowY: "auto",
          borderRadius: "var(--radius-lg)",
          padding: 24,
          position: "relative",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
          <h2 className="font-display" style={{ margin: 0, fontSize: 18, fontWeight: 600 }}>
            {isEdit ? "Edit task" : "Add task"}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            style={{ background: "none", border: "none", padding: 6, borderRadius: 8, color: "var(--text-2)" }}
          >
            <X size={18} />
          </button>
        </div>

        <label htmlFor="task-title" style={{ display: "block", fontSize: 12, color: "var(--text-2)", marginBottom: 6 }}>
          Task title
        </label>
        <input
          id="task-title"
          ref={titleRef}
          value={form.title}
          onChange={(e) => {
            setField("title", e.target.value);
            setError("");
          }}
          placeholder="What needs to get done?"
          className="input-field"
        />
        {error && <p style={{ color: "var(--accent-coral)", fontSize: 12, margin: "6px 0 0" }}>{error}</p>}

        <label htmlFor="task-desc" style={{ display: "block", fontSize: 12, color: "var(--text-2)", margin: "14px 0 6px" }}>
          Description
        </label>
        <textarea
          id="task-desc"
          rows={3}
          value={form.description}
          onChange={(e) => setField("description", e.target.value)}
          placeholder="Add a little more detail (optional)"
          className="input-field"
          style={{ resize: "none" }}
        />

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 14 }}>
          <div>
            <label htmlFor="task-category" style={{ display: "block", fontSize: 12, color: "var(--text-2)", marginBottom: 6 }}>
              Category
            </label>
            <select
              id="task-category"
              value={form.category}
              onChange={(e) => setField("category", e.target.value)}
              className="input-field"
            >
              {CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.id}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="task-date" style={{ display: "block", fontSize: 12, color: "var(--text-2)", marginBottom: 6 }}>
              Due date
            </label>
            <input
              id="task-date"
              type="date"
              value={form.dueDate}
              onChange={(e) => setField("dueDate", e.target.value)}
              className="input-field"
            />
          </div>
        </div>

        <label htmlFor="task-time" style={{ display: "block", fontSize: 12, color: "var(--text-2)", margin: "14px 0 6px" }}>
          Time (optional)
        </label>
        <input
          id="task-time"
          type="time"
          value={form.dueTime}
          onChange={(e) => setField("dueTime", e.target.value)}
          className="input-field"
          style={{ maxWidth: 160 }}
        />

        <p style={{ fontSize: 12, color: "var(--text-2)", margin: "16px 0 6px" }}>Priority</p>
        <div style={{ display: "flex", gap: 8 }}>
          {Object.entries(PRIORITIES).map(([key, p]) => (
            <button
              key={key}
              type="button"
              onClick={() => setField("priority", key)}
              style={{
                flex: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 5,
                padding: "9px 0",
                borderRadius: 10,
                fontSize: 12.5,
                fontWeight: 600,
                border: `1px solid ${form.priority === key ? p.color : "var(--border)"}`,
                background: form.priority === key ? `${p.color}22` : "var(--surface)",
                color: form.priority === key ? p.color : "var(--text-2)",
              }}
            >
              <Flame size={12} /> {p.label}
            </button>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
          <button
            type="button"
            onClick={onClose}
            className="btn-ghost"
            style={{ flex: 1, padding: "11px 0", borderRadius: 12, fontSize: 14, fontWeight: 500 }}
          >
            Cancel
          </button>
          <button type="submit" className="btn-primary" style={{ flex: 1, padding: "11px 0", borderRadius: 12, fontSize: 14, fontWeight: 600 }}>
            {isEdit ? "Save changes" : "Create task"}
          </button>
        </div>
      </form>
    </div>
  );
}
