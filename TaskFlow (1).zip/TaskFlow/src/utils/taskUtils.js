// Shared constants, sample data, and pure helper functions used across the app.

export const CATEGORIES = [
  { id: "Work", color: "#22d3ee" },
  { id: "Personal", color: "#fb7185" },
  { id: "Study", color: "#c084fc" },
  { id: "Health", color: "#4ade80" },
  { id: "Other", color: "#fbbf24" },
];

export const PRIORITIES = {
  high: { label: "High", color: "#fb7185" },
  medium: { label: "Medium", color: "#fbbf24" },
  low: { label: "Low", color: "#22d3ee" },
};

export const PRIORITY_RANK = { high: 0, medium: 1, low: 2 };

export const STORAGE_KEY = "taskflow.tasks.v1";
export const SEED_FLAG_KEY = "taskflow.seeded.v1";

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

const isoDaysFromNow = (n) => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
};

// Sample tasks used only the very first time the app runs (no saved data yet).
export function createSampleTasks() {
  const now = Date.now();
  return [
    {
      id: uid(),
      title: "Complete database assignment",
      description: "Finish ER diagram and SQL schema before submission.",
      category: "Study",
      priority: "high",
      dueDate: isoDaysFromNow(0),
      dueTime: "17:00",
      completed: false,
      createdAt: now - 90000,
    },
    {
      id: uid(),
      title: "Design onboarding flow",
      description: "Wireframe the first-run experience for new users.",
      category: "Work",
      priority: "high",
      dueDate: isoDaysFromNow(0),
      dueTime: "",
      completed: false,
      createdAt: now - 80000,
    },
    {
      id: uid(),
      title: "Reply to client proposal",
      description: "Send revised scope and timeline for the Q3 project.",
      category: "Work",
      priority: "medium",
      dueDate: isoDaysFromNow(1),
      dueTime: "",
      completed: false,
      createdAt: now - 70000,
    },
    {
      id: uid(),
      title: "Morning run",
      description: "5k around the park before the day gets busy.",
      category: "Health",
      priority: "low",
      dueDate: isoDaysFromNow(0),
      dueTime: "07:00",
      completed: true,
      createdAt: now - 60000,
    },
    {
      id: uid(),
      title: "Read two chapters",
      description: 'Continue "Designing Data-Intensive Applications".',
      category: "Study",
      priority: "low",
      dueDate: isoDaysFromNow(3),
      dueTime: "",
      completed: false,
      createdAt: now - 50000,
    },
    {
      id: uid(),
      title: "Prep quarterly deck",
      description: "Pull metrics and draft the narrative for leadership.",
      category: "Work",
      priority: "medium",
      dueDate: isoDaysFromNow(5),
      dueTime: "",
      completed: false,
      createdAt: now - 40000,
    },
    {
      id: uid(),
      title: "Grocery run",
      description: "Produce, coffee, and something for dinner tonight.",
      category: "Personal",
      priority: "low",
      dueDate: isoDaysFromNow(0),
      dueTime: "",
      completed: true,
      createdAt: now - 30000,
    },
    {
      id: uid(),
      title: "Refactor auth module",
      description: "Split token handling out of the request layer.",
      category: "Work",
      priority: "medium",
      dueDate: isoDaysFromNow(-2),
      dueTime: "",
      completed: false,
      createdAt: now - 20000,
    },
  ];
}

export function createEmptyTask() {
  return {
    id: uid(),
    title: "",
    description: "",
    category: "Work",
    priority: "medium",
    dueDate: isoDaysFromNow(0),
    dueTime: "",
    completed: false,
    createdAt: Date.now(),
  };
}

export function newTaskId() {
  return uid();
}

export function todayISO() {
  return isoDaysFromNow(0);
}

export function isToday(iso) {
  return !!iso && iso === todayISO();
}

export function isUpcoming(iso) {
  return !!iso && iso > todayISO();
}

export function isOverdue(task) {
  return !!task.dueDate && task.dueDate < todayISO() && !task.completed;
}

export function formatDueDate(iso) {
  if (!iso) return "No date";
  const d = new Date(iso + "T00:00:00");
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diffDays = Math.round((d - today) / 86400000);
  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Tomorrow";
  if (diffDays === -1) return "Yesterday";
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

export function formatFullDate(date = new Date()) {
  return date.toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
  });
}

export function categoryColor(id) {
  return (CATEGORIES.find((c) => c.id === id) || CATEGORIES[CATEGORIES.length - 1]).color;
}

// Applies search text, a filter keyword, and a sort mode to a task list.
export function filterAndSortTasks(tasks, { search = "", filter = "all", sortBy = "dueDate" } = {}) {
  let list = [...tasks];

  if (filter === "active") list = list.filter((t) => !t.completed);
  else if (filter === "completed") list = list.filter((t) => t.completed);
  else if (filter === "high") list = list.filter((t) => t.priority === "high");
  else if (filter === "medium") list = list.filter((t) => t.priority === "medium");
  else if (filter === "low") list = list.filter((t) => t.priority === "low");
  else if (filter === "today") list = list.filter((t) => isToday(t.dueDate));
  else if (filter === "upcoming") list = list.filter((t) => isUpcoming(t.dueDate));

  if (search.trim()) {
    const q = search.trim().toLowerCase();
    list = list.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q)
    );
  }

  list.sort((a, b) => {
    switch (sortBy) {
      case "priority":
        return PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority];
      case "recent":
        return b.createdAt - a.createdAt;
      case "alphabetical":
        return a.title.localeCompare(b.title);
      case "dueDate":
      default:
        return (a.dueDate || "9999-99-99").localeCompare(b.dueDate || "9999-99-99");
    }
  });

  return list;
}

export function computeStats(tasks) {
  const total = tasks.length;
  const completed = tasks.filter((t) => t.completed).length;
  const overdue = tasks.filter((t) => isOverdue(t)).length;
  const inProgress = total - completed - overdue < 0 ? total - completed : total - completed - overdue;
  return {
    total,
    completed,
    overdue,
    inProgress: Math.max(inProgress, 0),
    percent: total ? Math.round((completed / total) * 100) : 0,
  };
}
