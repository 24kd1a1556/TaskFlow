import { useEffect, useState, useCallback } from "react";
import { STORAGE_KEY, SEED_FLAG_KEY, createSampleTasks } from "../utils/taskUtils";

// Reads whatever is currently saved, seeding sample data only the very
// first time the app ever runs (tracked separately so that deleting all
// tasks later does not bring the samples back).
function loadInitialTasks() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);

    const alreadySeeded = localStorage.getItem(SEED_FLAG_KEY);
    if (!alreadySeeded) {
      const sample = createSampleTasks();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(sample));
      localStorage.setItem(SEED_FLAG_KEY, "true");
      return sample;
    }
    return [];
  } catch (err) {
    console.error("TaskFlow: could not read tasks from localStorage", err);
    return [];
  }
}

export function useTasks() {
  const [tasks, setTasks] = useState(loadInitialTasks);

  // Persist on every change.
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (err) {
      console.error("TaskFlow: could not save tasks to localStorage", err);
    }
  }, [tasks]);

  const addTask = useCallback((task) => {
    setTasks((prev) => [task, ...prev]);
  }, []);

  const updateTask = useCallback((task) => {
    setTasks((prev) => prev.map((t) => (t.id === task.id ? task : t)));
  }, []);

  const deleteTask = useCallback((id) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toggleComplete = useCallback((id) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
  }, []);

  return { tasks, addTask, updateTask, deleteTask, toggleComplete };
}
